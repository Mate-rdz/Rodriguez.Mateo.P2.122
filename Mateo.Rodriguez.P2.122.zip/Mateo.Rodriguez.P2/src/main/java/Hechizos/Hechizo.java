package Hechizos; 


import java.io.Serializable;
import java.util.Objects;

public class Hechizo implements Comparable<Hechizo>, CSVSerializable, Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String nombre;
    private String creador;
    private TipoHechizo tipo; 

    public Hechizo(int id, String nombre, String creador, TipoHechizo tipo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipo = tipo;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCreador() { return creador; }
    public TipoHechizo getTipo() { return tipo; }

    @Override
    public int compareTo(Hechizo o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toString() {
        return String.format("%d - %s (Creador: %s) [%s]", id, nombre, creador, tipo);
    }

    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%s", id, escapeCSV(nombre), escapeCSV(creador), tipo.name());
    }

    private String escapeCSV(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return '"' + s.replace("\"", "\"\"") + '"';
        }
        return s;
    }

    public static Hechizo fromCSV(String linea) {
        String[] parts = splitCSV(linea);
        if (parts.length < 4) throw new IllegalArgumentException("Linea CSV invalida: " + linea);
        int id = Integer.parseInt(parts[0].trim());
        String nombre = parts[1].trim();
        String creador = parts[2].trim();
        TipoHechizo tipo = TipoHechizo.valueOf(parts[3].trim());
        return new Hechizo(id, nombre, creador, tipo);
    }

    private static String[] splitCSV(String line) {
        java.util.List<String> out = new java.util.ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
                continue;
            }
            if (c == ',' && !inQuotes) {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out.toArray(new String[0]);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Hechizo)) return false;
        Hechizo hechizo = (Hechizo) o;
        return id == hechizo.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

package Hechizos; 

import java.io.*;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Consumer;

public class LibroDeHechizos<T extends CSVSerializable & Serializable> implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<T> elementos;

    public LibroDeHechizos() {
        elementos = new ArrayList<>();
    }

    public void agregar(T e) { elementos.add(e); }
    public T obtener(int index) { return elementos.get(index); }
    public T eliminar(int index) { return elementos.remove(index); }
    public int size() { return elementos.size(); }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> res = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) res.add(e);
        }
        return res;
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T e : elementos) accion.accept(e);
    }

    public void ordenar() {
        Collections.sort((List) elementos);
    }

    public void ordenar(Comparator<T> comp) {
        elementos.sort(comp);
    }

    
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            Object obj = ois.readObject();
            if (obj instanceof List) {
                elementos = (List<T>) obj;
            } else {
                throw new IOException("Contenido no válido");
            }
        }
    }

     
    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            for (T e : elementos) {
                pw.println(e.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        List<T> cargados = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                T obj = fromCSV.apply(line);
                cargados.add(obj);
            }
        }
        this.elementos = cargados;
    }
}
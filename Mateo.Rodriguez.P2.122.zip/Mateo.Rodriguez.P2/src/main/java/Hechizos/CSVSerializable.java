package Hechizos;

public interface CSVSerializable {
    String toCSV();
}  
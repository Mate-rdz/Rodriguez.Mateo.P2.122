package Hechizos;


import java.io.IOException;
import java.util.Comparator;

public class Main {

    public static void main(String[] args) {

        try {
            LibroDeHechizos<Hechizo> libro = new LibroDeHechizos<>();

            libro.agregar(new Hechizo(1, "Expelliarmus", "Flitwick", TipoHechizo.DEFENSA));
            libro.agregar(new Hechizo(2, "Alohomora", "Desconocido", TipoHechizo.UTILIDAD));
            libro.agregar(new Hechizo(3, "Sectumsempra", "Severus Snape", TipoHechizo.OSCURO));
            libro.agregar(new Hechizo(4, "Lumos", "Desconocido", TipoHechizo.ENCANTAMIENTO));
            libro.agregar(new Hechizo(5, "Vulnera Sanentur", "Snape", TipoHechizo.CURACION));

            System.out.println("Hechizos:");
            libro.paraCadaElemento(h -> System.out.println(h));

            System.out.println("\nHechizos DEFENSA:");
            libro.filtrar(h -> h.getTipo() == TipoHechizo.DEFENSA)
                 .forEach(System.out::println);

            System.out.println("\nHechizos que contienen 'lumos':");
            libro.filtrar(h -> h.getNombre().toLowerCase().contains("lumos"))
                 .forEach(System.out::println);

            System.out.println("\nOrdenados por ID:");
            libro.ordenar();
            libro.paraCadaElemento(System.out::println);

            System.out.println("\nOrdenados por nombre:");
            libro.ordenar(Comparator.comparing(Hechizo::getNombre));
            libro.paraCadaElemento(System.out::println);

            new java.io.File("src/data").mkdirs();
            libro.guardarEnArchivo("src/data/hechizos.dat");

            LibroDeHechizos<Hechizo> libroCargado = new LibroDeHechizos<>();
            libroCargado.cargarDesdeArchivo("src/data/hechizos.dat");

            System.out.println("\nCargados desde archivo binario:");
            libroCargado.paraCadaElemento(System.out::println);

            libro.guardarEnCSV("src/data/hechizos.csv");

            libroCargado.cargarDesdeCSV("src/data/hechizos.csv", Hechizo::fromCSV);

            System.out.println("\nCargados desde CSV:");
            libroCargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
